# Rural Electrification and Power Complaint Management System

A Flask + SQLite DBMS mini-project for managing village electricity complaints, power outages, new connection requests, and electrification progress.

## Features
- Resident complaint submission and complaint ID tracking
- Admin dashboard for assigning technicians and updating complaint status
- Power outage records and restoration status
- Village-level household electrification progress
- New electricity connection request form
- SQLite relational database with primary keys and foreign keys
- Demo seed data on first local startup

## Tech stack
- Python 3
- Flask
- SQLite
- HTML, CSS, Bootstrap 5
- Git and GitHub

## Run locally
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Create and activate a virtual environment (optional but recommended).
   - macOS/Linux: `python3 -m venv .venv && source .venv/bin/activate`
   - Windows: `py -m venv .venv` then `.venv\\Scripts\\activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Start the app: `python app.py`
6. Open `http://127.0.0.1:5000`

## Demo admin login
- Username: `admin`
- Password: `rural123`

**Security note:** demo credentials are for local demonstration only. Before any public deployment, implement proper password hashing, environment-based secrets, CSRF protection, and access controls. Do not put real residents' personal data in a public demo.

## Database tables
- `villages`
- `residents`
- `technicians`
- `complaints`
- `outages`
- `connection_requests`

## Publish source code on GitHub
1. Create a new GitHub repository named `rural-electrification-power-complaint-system`.
2. Upload these files, or run:
   ```bash
   git init
   git add .
   git commit -m "Initial rural power complaint system"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/rural-electrification-power-complaint-system.git
   git push -u origin main
   ```
3. GitHub stores and versions the source code. It does **not** run this Flask backend through GitHub Pages. To make the live application accessible online, deploy the Flask app to a Python web host (for example Render or another compatible service) and connect the GitHub repository.
4. For a persistent production database, use a managed PostgreSQL service or persistent disk; ephemeral SQLite storage on some hosts may reset.

## Suggested project extensions
- OTP-based resident verification
- SMS/email notifications
- Map of affected villages and feeders
- SLA timer and overdue complaint alerts
- Export monthly reports to CSV/PDF
- Role-based access for admin, operator, and technician
- PostgreSQL migration and audit log
